import 'package:shared_preferences/shared_preferences.dart';
import '../models/expense.dart';

/// Service responsible for persisting expense records to SharedPreferences.
class StorageService {
  static const String _expensesKey = 'smart_expense_tracker_items_v1';
  SharedPreferences? _prefs;

  /// Initializes SharedPreferences instance
  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  /// Saves the complete list of expenses to device storage
  Future<bool> saveExpenses(List<Expense> expenses) async {
    try {
      await init();
      final jsonString = Expense.encodeList(expenses);
      return await _prefs!.setString(_expensesKey, jsonString);
    } catch (e) {
      return false;
    }
  }

  /// Loads all saved expenses from device storage
  Future<List<Expense>> loadExpenses() async {
    try {
      await init();
      final jsonString = _prefs!.getString(_expensesKey);
      if (jsonString == null || jsonString.isEmpty) {
        return [];
      }
      return Expense.decodeList(jsonString);
    } catch (e) {
      return [];
    }
  }

  /// Clears all stored data (useful for reset/testing)
  Future<bool> clearAll() async {
    try {
      await init();
      return await _prefs!.remove(_expensesKey);
    } catch (e) {
      return false;
    }
  }
}
