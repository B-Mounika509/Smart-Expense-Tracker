import 'dart:convert';

/// Represents an expense item recorded by the user.
class Expense {
  final String id;
  final String title;
  final double amount;
  final DateTime date;
  final String category;
  final String note;

  Expense({
    required this.id,
    required this.title,
    required this.amount,
    required this.date,
    required this.category,
    this.note = '',
  });

  /// Factory constructor to deserialize JSON map from SharedPreferences
  factory Expense.fromJson(Map<String, dynamic> json) {
    return Expense(
      id: json['id'] as String,
      title: json['title'] as String? ?? 'Expense',
      amount: (json['amount'] as num).toDouble(),
      date: DateTime.parse(json['date'] as String),
      category: json['category'] as String,
      note: json['note'] as String? ?? '',
    );
  }

  /// Converts this instance into a JSON-compatible map
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'amount': amount,
      'date': date.toIso8601String(),
      'category': category,
      'note': note,
    };
  }

  /// Creates a copy with optionally updated fields
  Expense copyWith({
    String? id,
    String? title,
    double? amount,
    DateTime? date,
    String? category,
    String? note,
  }) {
    return Expense(
      id: id ?? this.id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      category: category ?? this.category,
      note: note ?? this.note,
    );
  }

  /// Helper to encode a list of expenses to JSON string
  static String encodeList(List<Expense> expenses) {
    return jsonEncode(expenses.map((e) => e.toJson()).toList());
  }

  /// Helper to decode a JSON string back into a list of expenses
  static List<Expense> decodeList(String jsonString) {
    if (jsonString.isEmpty) return [];
    final List<dynamic> decoded = jsonDecode(jsonString) as List<dynamic>;
    return decoded
        .map((item) => Expense.fromJson(item as Map<String, dynamic>))
        .toList();
  }
}

/// Standardized list of expense categories for college project requirement
class ExpenseCategories {
  static const String food = 'Food';
  static const String transport = 'Transport';
  static const String shopping = 'Shopping';
  static const String education = 'Education';
  static const String entertainment = 'Entertainment';
  static const String healthcare = 'Healthcare';
  static const String bills = 'Bills';
  static const String other = 'Other';

  static const List<String> all = [
    food,
    transport,
    shopping,
    education,
    entertainment,
    healthcare,
    bills,
    other,
  ];
}
