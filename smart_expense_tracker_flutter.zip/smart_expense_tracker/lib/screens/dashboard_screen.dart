import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/expense_provider.dart';
import '../widgets/summary_card.dart';
import '../widgets/category_chart.dart';
import '../widgets/expense_card.dart';
import 'expense_detail_screen.dart';

class DashboardScreen extends StatelessWidget {
  final VoidCallback onNavigateToExpenses;
  final VoidCallback onNavigateToAdd;

  const DashboardScreen({
    super.key,
    required this.onNavigateToExpenses,
    required this.onNavigateToAdd,
  });

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(locale: 'en_IN', symbol: '₹');
    final currentMonthName = DateFormat('MMMM yyyy').format(DateTime.now());

    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Expense Tracker'),
        actions: [
          IconButton(
            tooltip: 'Add Expense',
            icon: const Icon(Icons.add_circle_outline),
            onPressed: onNavigateToAdd,
          ),
        ],
      ),
      body: Consumer<ExpenseProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.hasError) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline, size: 48, color: Colors.red),
                  const SizedBox(height: 12),
                  Text(provider.errorMessage ?? 'An error occurred'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => provider.loadExpenses(),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          final recentExpenses = provider.recentExpenses;

          return RefreshIndicator(
            onRefresh: () => provider.loadExpenses(),
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // KPI Summary Cards: Total + Current Month
                  Row(
                    children: [
                      Expanded(
                        child: SummaryCard(
                          title: 'Total Spent',
                          amount: currencyFormat.format(provider.totalExpenses),
                          subtitle: '${provider.expenses.length} transactions',
                          icon: Icons.account_balance_wallet,
                          isPrimary: true,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: SummaryCard(
                          title: currentMonthName,
                          amount: currencyFormat.format(provider.currentMonthExpenses),
                          subtitle: 'Current Month',
                          icon: Icons.calendar_month,
                          isPrimary: false,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Category Breakdown Chart Card
                  const Text(
                    'Category Breakdown',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  CategoryChart(categoryData: provider.categorySpending),
                  const SizedBox(height: 24),

                  // Recent Transactions Header & List
                  Row(
                    mainAxisAlignment: MainAxisAlignment.between,
                    children: [
                      const Text(
                        'Recent Transactions',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      if (provider.expenses.isNotEmpty)
                        TextButton(
                          onPressed: onNavigateToExpenses,
                          child: const Text('View All'),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  if (recentExpenses.isEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 16),
                        child: Center(
                          child: Column(
                            children: [
                              Icon(Icons.receipt_long, size: 48, color: Theme.of(context).colorScheme.outline),
                              const SizedBox(height: 12),
                              const Text('No expenses recorded yet', style: TextStyle(fontWeight: FontWeight.w600)),
                              const SizedBox(height: 4),
                              const Text('Tap the button below to add your first expense.', style: TextStyle(color: Colors.grey)),
                              const SizedBox(height: 16),
                              ElevatedButton.icon(
                                onPressed: onNavigateToAdd,
                                icon: const Icon(Icons.add),
                                label: const Text('Add Expense'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                  else
                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: recentExpenses.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (context, index) {
                        final expense = recentExpenses[index];
                        return ExpenseCard(
                          expense: expense,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => ExpenseDetailScreen(expenseId: expense.id),
                              ),
                            );
                          },
                        );
                      },
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
