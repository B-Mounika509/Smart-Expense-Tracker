import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/expense_provider.dart';
import 'services/storage_service.dart';
import 'theme/app_theme.dart';
import 'widgets/bottom_navigation.dart';

void main() async {
  // Ensure Flutter engine bindings are initialized before calling async plugins
  WidgetsFlutterBinding.ensureInitialized();

  // Pre-initialize local storage service
  final storageService = StorageService();
  await storageService.init();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => ExpenseProvider(storageService)..loadExpenses(),
        ),
      ],
      child: const SmartExpenseApp(),
    ),
  );
}

class SmartExpenseApp extends StatelessWidget {
  const SmartExpenseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Expense Tracker',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system, // Automatically matches device setting
      home: const MainNavigationWrapper(),
    );
  }
}
