import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

class CategoryChart extends StatelessWidget {
  final Map<String, double> categoryData;

  const CategoryChart({
    super.key,
    required this.categoryData,
  });

  static const List<Color> _palette = [
    Color(0xFFE06D53), // Food
    Color(0xFF3B82F6), // Transport
    Color(0xFF8B5CF6), // Shopping
    Color(0xFF059669), // Education
    Color(0xFFEC4899), // Entertainment
    Color(0xFFEF4444), // Healthcare
    Color(0xFFD97706), // Bills
    Color(0xFF64748B), // Other
  ];

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.compactSimpleCurrency(locale: 'en_IN', name: '₹');

    // Filter out categories with zero expenditure
    final activeCategories = categoryData.entries
        .where((entry) => entry.value > 0)
        .toList();

    final totalSpent = activeCategories.fold<double>(
      0.0,
      (sum, entry) => sum + entry.value,
    );

    if (activeCategories.isEmpty || totalSpent == 0) {
      return Card(
        child: Container(
          padding: const EdgeInsets.all(24),
          alignment: Alignment.center,
          child: Column(
            children: [
              Icon(Icons.pie_chart_outline, size: 40, color: Theme.of(context).colorScheme.outline),
              const SizedBox(height: 8),
              const Text('No spending data to visualize', style: TextStyle(color: Colors.grey)),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(
              height: 180,
              child: PieChart(
                PieChartData(
                  sectionsSpace: 2,
                  centerSpaceRadius: 40,
                  sections: List.generate(activeCategories.length, (index) {
                    final entry = activeCategories[index];
                    final percentage = (entry.value / totalSpent) * 100;
                    final color = _palette[index % _palette.length];

                    return PieChartSectionData(
                      color: color,
                      value: entry.value,
                      title: '${percentage.toStringAsFixed(0)}%',
                      radius: 36,
                      titleStyle: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    );
                  }),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 12,
              runSpacing: 8,
              children: List.generate(activeCategories.length, (index) {
                final entry = activeCategories[index];
                final color = _palette[index % _palette.length];
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      '${entry.key}: ${currencyFormat.format(entry.value)}',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                );
              }),
            ),
          ],
        ),
      ),
    );
  }
}
