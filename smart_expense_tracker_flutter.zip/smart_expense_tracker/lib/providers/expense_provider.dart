import 'package:flutter/foundation.dart';
import '../models/expense.dart';
import '../services/storage_service.dart';

enum ExpenseStateStatus { initial, loading, loaded, error }

/// Main state management provider for Smart Expense Tracker.
class ExpenseProvider extends ChangeNotifier {
  final StorageService _storageService;

  ExpenseProvider(this._storageService);

  List<Expense> _expenses = [];
  ExpenseStateStatus _status = ExpenseStateStatus.initial;
  String? _errorMessage;

  // Getters
  List<Expense> get expenses => List.unmodifiable(_expenses);
  ExpenseStateStatus get status => _status;
  bool get isLoading => _status == ExpenseStateStatus.loading;
  bool get hasError => _status == ExpenseStateStatus.error;
  String? get errorMessage => _errorMessage;

  /// Returns total expenses across all time
  double get totalExpenses {
    return _expenses.fold<double>(0.0, (sum, item) => sum + item.amount);
  }

  /// Returns current month's expenses
  double get currentMonthExpenses {
    final now = DateTime.now();
    return _expenses.where((e) {
      return e.date.year == now.year && e.date.month == now.month;
    }).fold<double>(0.0, (sum, item) => sum + item.amount);
  }

  /// Returns a map of category names to their respective total spent
  Map<String, double> get categorySpending {
    final Map<String, double> totals = {};
    for (final cat in ExpenseCategories.all) {
      totals[cat] = 0.0;
    }
    for (final exp in _expenses) {
      totals[exp.category] = (totals[exp.category] ?? 0.0) + exp.amount;
    }
    return totals;
  }

  /// Returns the most recent 5 expenses sorted by date descending
  List<Expense> get recentExpenses {
    final sorted = List<Expense>.from(_expenses)
      ..sort((a, b) => b.date.compareTo(a.date));
    return sorted.take(5).toList();
  }

  /// Loads expenses from SharedPreferences with simulated loading state
  Future<void> loadExpenses() async {
    _status = ExpenseStateStatus.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      final loaded = await _storageService.loadExpenses();
      _expenses = loaded;
      // Sort newly loaded by date descending
      _expenses.sort((a, b) => b.date.compareTo(a.date));
      _status = ExpenseStateStatus.loaded;
    } catch (e) {
      _status = ExpenseStateStatus.error;
      _errorMessage = 'Failed to load expenses from local storage.';
    }

    notifyListeners();
  }

  /// Adds a new expense, saves it locally, and updates listeners
  Future<bool> addExpense(Expense expense) async {
    try {
      _expenses.insert(0, expense); // Prepend so it appears top of list
      _expenses.sort((a, b) => b.date.compareTo(a.date));
      final success = await _storageService.saveExpenses(_expenses);
      notifyListeners();
      return success;
    } catch (e) {
      return false;
    }
  }

  /// Deletes an expense by ID, updates storage, and notifies listeners
  Future<bool> deleteExpense(String id) async {
    try {
      _expenses.removeWhere((item) => item.id == id);
      final success = await _storageService.saveExpenses(_expenses);
      notifyListeners();
      return success;
    } catch (e) {
      return false;
    }
  }
}
