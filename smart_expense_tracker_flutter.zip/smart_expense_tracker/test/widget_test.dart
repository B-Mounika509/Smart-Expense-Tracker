import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:smart_expense_tracker/models/expense.dart';
import 'package:smart_expense_tracker/providers/expense_provider.dart';
import 'package:smart_expense_tracker/services/storage_service.dart';
import 'package:smart_expense_tracker/screens/add_expense_screen.dart';

/// In-memory mock storage service for testing without device SharedPreferences
class MockStorageService extends StorageService {
  final List<Expense> _mockStore = [];

  @override
  Future<void> init() async {}

  @override
  Future<bool> saveExpenses(List<Expense> expenses) async {
    _mockStore.clear();
    _mockStore.addAll(expenses);
    return true;
  }

  @override
  Future<List<Expense>> loadExpenses() async {
    return List.from(_mockStore);
  }
}

void main() {
  testWidgets('Smart Expense Tracker - Add Expense Form Validation Test', (WidgetTester tester) async {
    final mockStorage = MockStorageService();
    final expenseProvider = ExpenseProvider(mockStorage);

    bool savedCallbackTriggered = false;

    // Pump the AddExpenseScreen inside MaterialApp with ExpenseProvider
    await tester.pumpWidget(
      ChangeNotifierProvider<ExpenseProvider>.value(
        value: expenseProvider,
        child: MaterialApp(
          home: AddExpenseScreen(
            onSavedSuccess: () {
              savedCallbackTriggered = true;
            },
          ),
        ),
      ),
    );

    // Verify presence of input fields
    expect(find.text('Add New Expense'), findsOneWidget);
    expect(find.byType(TextFormField), findsNWidgets(2)); // Amount & Note

    // Attempt to submit empty form
    final saveButton = find.widgetWithText(ElevatedButton, 'Save Expense');
    expect(saveButton, findsOneWidget);
    await tester.tap(saveButton);
    await tester.pump();

    // Verify validation error is displayed
    expect(find.text('Please enter the expense amount'), findsOneWidget);

    // Enter valid amount
    final amountField = find.byType(TextFormField).first;
    await tester.enterText(amountField, '250.50');
    await tester.pump();

    // Submit form with valid amount
    await tester.tap(saveButton);
    await tester.pumpAndSettle();

    // Verify provider updated and callback triggered
    expect(expenseProvider.expenses.length, 1);
    expect(expenseProvider.expenses.first.amount, 250.50);
    expect(savedCallbackTriggered, isTrue);
  });
}
